export CSE120_HOST="-DHOST_i386"
export CSE120_COMMON_CFLAGS="-m32"
export CSE120_COMMON_ASFLAGS="--32"
export CSE120_LDFLAGS="-m32"
export CSE120_CFLAGS="-m32 -I./ -I../threads -g"
export CSE120_GCC=/home/sargdsra/Desktop/Nachos_Operating_Systems_Course/mips-x86.linux-xgcc/
export MAKE_CMD="make"
